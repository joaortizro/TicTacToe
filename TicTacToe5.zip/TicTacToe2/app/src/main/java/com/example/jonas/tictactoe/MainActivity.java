package com.example.jonas.tictactoe;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.nfc.Tag;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MAIN";
    private TicTacToeConsole mGame;
    private Button mBoardButtons[];
    public enum DifficultyLevel {Easy, Harder, Expert};
    private DifficultyLevel mDifficultyLevel = DifficultyLevel.Expert;
    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    private BoardView mBoardView;
    private boolean mGameOver;
    public int winner;
    private boolean mSoundOn = true;


    //sounds
    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;
    //alert
    AlertDialog.Builder builder;
    AlertDialog dialog;
/*    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBoardButtons = new Button[9];
        mBoardButtons[0] = (Button) findViewById(R.id.one);
        mBoardButtons[1] = (Button) findViewById(R.id.two);
        mBoardButtons[2] = (Button) findViewById(R.id.three);
        mBoardButtons[3] = (Button) findViewById(R.id.four);
        mBoardButtons[4] = (Button) findViewById(R.id.five);
        mBoardButtons[5] = (Button) findViewById(R.id.six);
        mBoardButtons[6] = (Button) findViewById(R.id.seven);
        mBoardButtons[7] = (Button) findViewById(R.id.eight);
        mBoardButtons[8] = (Button) findViewById(R.id.nine);
        mGame = new TicTacToeConsole();
        startNewGame();
    }*/
    public void setAudio (){
        Context context = MainActivity.this;
        AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        switch( audio.getRingerMode() ){
            case AudioManager.RINGER_MODE_NORMAL:
                mSoundOn=true;
                break;
            case AudioManager.RINGER_MODE_SILENT:
                mSoundOn=false;
                break;
            case AudioManager.RINGER_MODE_VIBRATE:
                mSoundOn=false;
                break;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mGame = new TicTacToeConsole();
        setAudio();
        //mSoundOn = mPrefs.getBoolean("sound", true);
        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setGame(mGame);
        mBoardView.setOnTouchListener(mTouchListener);
        builder= new AlertDialog.Builder(MainActivity.this);
        dialog=builder.create();
        startNewGame();
    }

    public void startNewGame(){
        mGameOver=false;
        mGame.clearBoard();
        mBoardView.invalidate();
    }

    private boolean setMove(char player, int location) {
        //generalComputerPos=location;
        final int computerLocation=location;

        if(mGame.isEnable(player, location) ) {
            if(player==mGame.HUMAN_PLAYER){
                if( mSoundOn)  mHumanMediaPlayer.start();
                mGame.setMove(mGame.HUMAN_PLAYER, location);
            }
            if(player == mGame.COMPUTER_PLAYER){
                //handlerTime();
                if( mSoundOn)  mComputerMediaPlayer.start();
                mGame.setMove(mGame.COMPUTER_PLAYER, computerLocation);
/*                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if( mSoundOn)  mComputerMediaPlayer.start();
                        mGame.setMove(mGame.COMPUTER_PLAYER, computerLocation);
                    }
                }, 1000);*/
            }
            mBoardView.invalidate();
            return true;
        }

        return false;
    }

    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {

        public boolean onTouch(View v, MotionEvent event) {
            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;
            if (mGame.isEnable(TicTacToeConsole.HUMAN_PLAYER, pos) )	{
                setMove(TicTacToeConsole.HUMAN_PLAYER, pos);
                // If no winner yet, let the computer make a move
                Log.d(TAG, "winner"+winner);
                winner = mGame.checkForWinner();
                if (winner == 0) {
                    int move = mGame.getComputerMove();
                    setMove(TicTacToeConsole.COMPUTER_PLAYER, move);
                    winner = mGame.checkForWinner();
                }
                else if (winner == 1) {
                    builder.setTitle("Fin del juego");
                    builder.setMessage("Empate");
                    builder.show();
                }
                else if (winner == 2) {
                    builder.setTitle("Fin del juego");
                    builder.setMessage("Ganaste");
                    builder.show();
                }
                else {
                    builder.setTitle("Fin del juego");
                    builder.setMessage("Gana la computadora");
                    builder.show();
                }
                //Log.d(TAG, "onTouch: "+ mGameOver);

            }
            return false;
        }
    };


@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        navigation.inflateMenu(R.menu.options_menu);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.new_game:
                        startNewGame();
                        break;
                    case R.id.ai_difficulty:
                        showDialog(DIALOG_DIFFICULTY_ID);
                        break;
                    case R.id.quit:
                        showDialog(DIALOG_QUIT_ID);
                        break;
                }
                return true;
            }
        });
        return true;
    }

    /*private class ButtonClickListener implements View.OnClickListener {
        int location;
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        AlertDialog dialog=builder.create();
        public ButtonClickListener(int location) {
            this.location = location;
        }

        public void onClick(View view) {

            if (mBoardButtons[location].isEnabled()) {
                setMove(TicTacToeConsole.HUMAN_PLAYER, location);

                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();
                if (winner == 0) {
                    int move = mGame.getComputerMove();
                    setMove(TicTacToeConsole.COMPUTER_PLAYER, move);
                    winner = mGame.checkForWinner();
                }

                else if (winner == 1){
                    builder.setTitle("Fin del juego");
                    builder.setMessage("Empate");
                    builder.show();
                }

                else if (winner == 2){

                    builder.setTitle("Fin del juego");
                    builder.setMessage("Ganaste");
                    builder.show();
                }

                else{
                    builder.setTitle("Fin del juego");
                    builder.setMessage("Gana la computadora");
                    builder.show();
                }

            }
        }
    }*/
   protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        switch(id) {
            case DIALOG_DIFFICULTY_ID:
                builder.setTitle(R.string.difficutly_choose);
                final CharSequence[] levels = {
                        getResources().getString(R.string.difficutly_easy),
                        getResources().getString(R.string.difficutly_harder),
                        getResources().getString(R.string.difficutly_expert)};
                int selected =0;
                builder.setSingleChoiceItems(levels, selected,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                dialog.dismiss();
                                Toast.makeText(getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();
                break;
            case DIALOG_QUIT_ID:

                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                MainActivity.this.finish();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();
                break;
        }
        return dialog;
    }

    protected void onResume() {
        super.onResume();
        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.sound1);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.sound2);
    }
    @Override
    protected void onPause() {
        super.onPause();
        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
    }

}
